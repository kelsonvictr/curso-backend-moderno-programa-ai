# Biblioteca do Bairro

Projeto do Cap 04 (SOLID à mão). Você escreve o código; o agente, se usado, só revisa.

## Rodar os testes
    ./mvnw test            (Windows: mvnw.cmd test)

A primeira vez baixa o Maven e demora. Procure a linha `Tests run:` e o `BUILD SUCCESS`.

## Rodar o programa de exemplo
No IntelliJ, abra `App.java` e clique no triângulo verde ao lado de `main`.
Pelo terminal:

    ./mvnw -q compile
    java -cp target/classes br.com.biblioteca.App

No Windows, troque a barra: `java -cp target\classes br.com.biblioteca.App`.
