package br.com.biblioteca;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;

import org.junit.jupiter.api.Test;

class BibliotecaTest {

    private final Biblioteca biblioteca = new Biblioteca();
    private Livro domCasmurro() {
        return new Livro("L-001", "Dom Casmurro");
    }

    private Leitor leitor(String nome, TipoDeLeitor tipo) {
        return new Leitor(nome, nome.toLowerCase() + "@email.com", tipo);
    }

    @Test
    void emprestarDeixaOLivroIndisponivel() {
        Livro livro = domCasmurro();
        biblioteca.emprestar(livro);
        assertFalse(livro.estaDisponivel());
    }

    @Test
    void naoEmprestaOMesmoLivroDuasVezes() {
        Livro livro = domCasmurro();
        biblioteca.emprestar(livro);
        assertThrows(IllegalStateException.class, () -> biblioteca.emprestar(livro));
    }

    @Test
    void devolverNoPrazoNaoGeraMulta() {
        Livro livro = domCasmurro();
        biblioteca.emprestar(livro);
        assertEquals(0, biblioteca.devolver(livro, leitor("Ana", new Aluno()), 0));
    }

    @Test
    void devolverComAtrasoCobraAMulta() {
        Livro livro = domCasmurro();
        biblioteca.emprestar(livro);
        assertEquals(300, biblioteca.devolver(livro, leitor("Ana", new Aluno()), 3));
    }
}
