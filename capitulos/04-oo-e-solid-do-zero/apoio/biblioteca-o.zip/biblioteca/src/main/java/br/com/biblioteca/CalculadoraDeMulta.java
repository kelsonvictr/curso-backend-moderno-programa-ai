package br.com.biblioteca;

/**
 * Sabe uma coisa só: quanto custa o atraso.
 * Cada tipo de leitor diz quanto paga por dia; a calculadora só multiplica.
 */
public class CalculadoraDeMulta {

    public int calcular(Leitor leitor, int diasDeAtraso) {
        return diasDeAtraso * leitor.getTipo().multaPorDiaEmCentavos();
    }
}
