package br.com.biblioteca;

/** Aluno paga 100 centavos (R$ 1,00) por dia de atraso. */
public class Aluno implements TipoDeLeitor {

    @Override
    public int multaPorDiaEmCentavos() {
        return 100;
    }
}
