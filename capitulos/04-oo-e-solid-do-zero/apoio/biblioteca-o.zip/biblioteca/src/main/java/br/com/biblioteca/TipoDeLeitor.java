package br.com.biblioteca;

/**
 * Contrato: todo tipo de leitor sabe quanto paga por dia de atraso.
 * Tipo novo = classe nova. Ninguém precisa editar a calculadora.
 */
public interface TipoDeLeitor {

    int multaPorDiaEmCentavos();
}
