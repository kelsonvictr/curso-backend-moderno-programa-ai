package br.com.biblioteca;

/** Professor paga 50 centavos (R$ 0,50) por dia de atraso. */
public class Professor implements TipoDeLeitor {

    @Override
    public int multaPorDiaEmCentavos() {
        return 50;
    }
}
