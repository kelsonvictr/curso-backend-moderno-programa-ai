package br.com.biblioteca;

/** Visitante paga 200 centavos (R$ 2,00) por dia de atraso. */
public class Visitante implements TipoDeLeitor {

    @Override
    public int multaPorDiaEmCentavos() {
        return 200;
    }
}
