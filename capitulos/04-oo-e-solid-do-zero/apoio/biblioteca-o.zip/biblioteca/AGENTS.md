# Biblioteca do Bairro — instruções para o agente

Projeto de aula (Cap 04: SOLID à mão). Java 21 puro, Maven Wrapper e JUnit 5.
Não há Spring, banco de dados, Docker nem rede de verdade.

## Quem escreve o código
O aluno escreve o código à mão, para aprender. Você é revisor.
- Não edite nenhum arquivo, a menos que o aluno peça com todas as letras.
- Ao revisar, aponte arquivo e linha, diga qual conselho do SOLID está em jogo e por quê,
  em português simples. Não reescreva a solução inteira: mostre só o trecho necessário.
- Se estiver tudo certo, diga que está certo. Não invente problema para parecer útil.

## Como rodar
- Testes: `./mvnw test` (no Windows: `mvnw.cmd test`).
- Programa de exemplo: `./mvnw -q compile` e depois `java -cp target/classes br.com.biblioteca.App`.

## Regras do código
- Sem dependências novas, frameworks, Lombok, records, lambdas ou streams em `src/main`.
  Nos testes, a única lambda é a do `assertThrows(..., () -> ...)`.
- Valores de dinheiro são inteiros em centavos (300 = R$ 3,00).

## Domínio
- Livro: código, título e se está disponível. Só o próprio livro muda esse estado.
- Leitor: nome, e-mail e tipo. Multa por dia de atraso: aluno 100, professor 50, visitante 200.
- Obras de consulta (dicionários) ficam no acervo, mas nunca saem da biblioteca.
- Se houver multa, o leitor recebe um aviso. `EmailSmtp` simula o envio e demora 2 segundos.
