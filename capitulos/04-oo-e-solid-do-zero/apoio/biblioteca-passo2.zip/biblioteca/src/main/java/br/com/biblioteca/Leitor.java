package br.com.biblioteca;

/**
 * Quem pega livros emprestados.
 * O tipo é um texto: "ALUNO" ou "PROFESSOR".
 */
public class Leitor {

    private final String nome;
    private final String email;
    private final String tipo;

    public Leitor(String nome, String email, String tipo) {
        this.nome = nome;
        this.email = email;
        this.tipo = tipo;
    }

    public String getNome() {
        return nome;
    }

    public String getEmail() {
        return email;
    }

    public String getTipo() {
        return tipo;
    }
}
