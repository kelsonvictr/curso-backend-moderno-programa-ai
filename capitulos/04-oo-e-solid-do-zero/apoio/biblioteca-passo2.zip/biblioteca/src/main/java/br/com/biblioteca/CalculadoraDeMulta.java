package br.com.biblioteca;

/**
 * Sabe uma coisa só: quanto custa o atraso.
 * Se a regra de multa mudar, esta é a única classe que muda.
 */
public class CalculadoraDeMulta {

    public int calcular(Leitor leitor, int diasDeAtraso) {
        if (leitor.getTipo().equals("ALUNO")) {
            return diasDeAtraso * 100;
        }
        if (leitor.getTipo().equals("PROFESSOR")) {
            return diasDeAtraso * 50;
        }
        return 0;
    }
}
