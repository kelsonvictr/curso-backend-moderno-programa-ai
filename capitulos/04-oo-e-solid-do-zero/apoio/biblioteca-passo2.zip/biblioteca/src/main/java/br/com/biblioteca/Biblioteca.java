package br.com.biblioteca;

/**
 * O balcão da biblioteca. Agora ele coordena:
 * o livro cuida de si, a calculadora cuida da multa.
 * O aviso ainda está preso ao EmailSmtp.
 */
public class Biblioteca {

    private final CalculadoraDeMulta calculadora = new CalculadoraDeMulta();

    public void emprestar(Livro livro) {
        livro.emprestar();
    }

    public int devolver(Livro livro, Leitor leitor, int diasDeAtraso) {
        livro.devolver();

        int multa = calculadora.calcular(leitor, diasDeAtraso);

        if (multa > 0) {
            EmailSmtp email = new EmailSmtp();
            email.enviar(leitor.getEmail(), "Multa de " + multa + " centavos por " + diasDeAtraso + " dia(s) de atraso.");
        }
        return multa;
    }
}
