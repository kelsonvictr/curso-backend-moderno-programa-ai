package br.com.biblioteca;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

class CalculadoraDeMultaTest {

    private final CalculadoraDeMulta calculadora = new CalculadoraDeMulta();

    @Test
    void alunoPagaCemCentavosPorDia() {
        Leitor ana = new Leitor("Ana", "ana@email.com", "ALUNO");
        assertEquals(300, calculadora.calcular(ana, 3));
    }

    @Test
    void professorPagaCinquentaCentavosPorDia() {
        Leitor bruno = new Leitor("Bruno", "bruno@email.com", "PROFESSOR");
        assertEquals(150, calculadora.calcular(bruno, 3));
    }

    @Test
    void semAtrasoNaoHaMulta() {
        Leitor ana = new Leitor("Ana", "ana@email.com", "ALUNO");
        assertEquals(0, calculadora.calcular(ana, 0));
    }
}
