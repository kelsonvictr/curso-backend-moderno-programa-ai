package br.com.biblioteca;

/**
 * Um dia no balcão: Ana pega Dom Casmurro e devolve com 3 dias de atraso.
 */
public class App {

    public static void main(String[] args) {
        Livro livro = new Livro("L-001", "Dom Casmurro");
        Leitor ana = new Leitor("Ana", "ana@email.com", new Aluno());

        // É aqui, na montagem, que escolhemos o e-mail de verdade (simulado).
        Biblioteca biblioteca = new Biblioteca(new EmailSmtp());
        biblioteca.emprestar(livro);
        System.out.println(livro.getTitulo() + " disponível? " + livro.estaDisponivel());

        int multa = biblioteca.devolver(livro, ana, 3);
        System.out.println("Multa: " + multa + " centavos");
        System.out.println(livro.getTitulo() + " disponível? " + livro.estaDisponivel());
    }
}
