package br.com.biblioteca;

/**
 * O balcão da biblioteca. Só coordena:
 * o livro cuida de si, a calculadora cuida da multa e o notificador cuida do aviso.
 * Quem cria a Biblioteca escolhe qual notificador ela vai usar.
 */
public class Biblioteca {

    private final CalculadoraDeMulta calculadora = new CalculadoraDeMulta();
    private final Notificador notificador;

    public Biblioteca(Notificador notificador) {
        this.notificador = notificador;
    }

    public void emprestar(Livro livro) {
        livro.emprestar();
    }

    public int devolver(Livro livro, Leitor leitor, int diasDeAtraso) {
        livro.devolver();

        int multa = calculadora.calcular(leitor, diasDeAtraso);

        if (multa > 0) {
            notificador.avisar(leitor, "Multa de " + multa + " centavos por " + diasDeAtraso + " dia(s) de atraso.");
        }
        return multa;
    }
}
