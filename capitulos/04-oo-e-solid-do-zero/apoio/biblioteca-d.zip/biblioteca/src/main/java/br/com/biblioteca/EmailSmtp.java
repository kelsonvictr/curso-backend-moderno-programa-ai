package br.com.biblioteca;

/**
 * Finge que manda um e-mail.
 * Demora 2 segundos de propósito, como uma conexão de verdade com um servidor de e-mail.
 */
public class EmailSmtp implements Notificador {

    @Override
    public void avisar(Leitor leitor, String mensagem) {
        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
        System.out.println("[e-mail] para " + leitor.getEmail() + ": " + mensagem);
    }
}
