package br.com.biblioteca;

import java.util.List;

/**
 * O balcão da biblioteca. Só coordena: o livro cuida de si, a calculadora cuida da multa
 * e o notificador cuida do aviso. Quem cria a Biblioteca escolhe o notificador.
 */
public class Biblioteca {

    private final CalculadoraDeMulta calculadora = new CalculadoraDeMulta();
    private final Notificador notificador;

    public Biblioteca(Notificador notificador) {
        this.notificador = notificador;
    }

    public void emprestar(Livro livro) {
        livro.emprestar();
    }

    public void emprestarTodos(List<Livro> livros) {
        for (Livro livro : livros) {
            livro.emprestar();
        }
    }

    public int devolver(Livro livro, Leitor leitor, int diasDeAtraso) {
        livro.devolver();

        int multa = calculadora.calcular(leitor, diasDeAtraso);

        if (multa > 0) {
            notificador.avisar(leitor, "Multa de " + multa + " centavos por " + diasDeAtraso + " dia(s) de atraso.");
        }
        return multa;
    }
}
