package br.com.biblioteca;

/**
 * Contrato: alguém que sabe avisar um leitor.
 * A Biblioteca depende deste contrato, não de como o aviso chega (e-mail, WhatsApp, teste).
 */
public interface Notificador {

    void avisar(Leitor leitor, String mensagem);
}
