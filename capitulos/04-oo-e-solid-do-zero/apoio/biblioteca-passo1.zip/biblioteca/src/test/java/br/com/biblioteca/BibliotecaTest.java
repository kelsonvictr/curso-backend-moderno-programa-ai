package br.com.biblioteca;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

class BibliotecaTest {

    private Livro domCasmurro() {
        return new Livro("L-001", "Dom Casmurro");
    }

    private Leitor leitor(String nome, String tipo) {
        return new Leitor(nome, nome.toLowerCase() + "@email.com", tipo);
    }

    @Test
    void emprestarDeixaOLivroIndisponivel() {
        Livro livro = domCasmurro();
        new Biblioteca().emprestar(livro);
        assertFalse(livro.estaDisponivel());
    }

    @Test
    void devolverNoPrazoNaoGeraMulta() {
        Biblioteca biblioteca = new Biblioteca();
        Livro livro = domCasmurro();
        biblioteca.emprestar(livro);
        assertEquals(0, biblioteca.devolver(livro, leitor("Ana", "ALUNO"), 0));
        assertTrue(livro.estaDisponivel());
    }

    @Test
    void alunoPagaCemCentavosPorDiaDeAtraso() {
        Biblioteca biblioteca = new Biblioteca();
        Livro livro = domCasmurro();
        biblioteca.emprestar(livro);
        assertEquals(300, biblioteca.devolver(livro, leitor("Ana", "ALUNO"), 3));
    }

    @Test
    void professorPagaCinquentaCentavosPorDiaDeAtraso() {
        Biblioteca biblioteca = new Biblioteca();
        Livro livro = domCasmurro();
        biblioteca.emprestar(livro);
        assertEquals(150, biblioteca.devolver(livro, leitor("Bruno", "PROFESSOR"), 3));
    }

    // Era o bug conhecido do início. Agora o próprio livro recusa o segundo empréstimo.
    @Test
    void naoEmprestaOMesmoLivroDuasVezes() {
        Biblioteca biblioteca = new Biblioteca();
        Livro livro = domCasmurro();
        biblioteca.emprestar(livro);
        assertThrows(IllegalStateException.class, () -> biblioteca.emprestar(livro));
    }

    @Test
    void naoDevolveLivroQueNaoFoiEmprestado() {
        Livro livro = domCasmurro();
        assertThrows(IllegalStateException.class, () -> new Biblioteca().devolver(livro, leitor("Ana", "ALUNO"), 0));
    }
}
