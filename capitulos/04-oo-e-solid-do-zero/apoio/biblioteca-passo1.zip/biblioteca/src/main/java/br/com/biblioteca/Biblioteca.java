package br.com.biblioteca;

/**
 * O balcão da biblioteca. Ainda faz muita coisa:
 * pede ao livro para mudar, calcula a multa e manda o aviso.
 */
public class Biblioteca {

    public void emprestar(Livro livro) {
        livro.emprestar();
    }

    public int devolver(Livro livro, Leitor leitor, int diasDeAtraso) {
        livro.devolver();

        int multa = 0;
        if (leitor.getTipo().equals("ALUNO")) {
            multa = diasDeAtraso * 100;
        } else if (leitor.getTipo().equals("PROFESSOR")) {
            multa = diasDeAtraso * 50;
        }

        if (multa > 0) {
            EmailSmtp email = new EmailSmtp();
            email.enviar(leitor.getEmail(), "Multa de " + multa + " centavos por " + diasDeAtraso + " dia(s) de atraso.");
        }
        return multa;
    }
}
