package br.com.biblioteca;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

class BibliotecaTest {

    private Livro domCasmurro() {
        return new Livro("L-001", "Dom Casmurro");
    }

    private Leitor leitor(String nome, TipoDeLeitor tipo) {
        return new Leitor(nome, nome.toLowerCase() + "@email.com", tipo);
    }

    @Test
    void emprestarDeixaOLivroIndisponivel() {
        Livro livro = domCasmurro();
        new Biblioteca().emprestar(livro);
        assertFalse(livro.estaDisponivel());
    }

    @Test
    void devolverNoPrazoNaoGeraMulta() {
        Biblioteca biblioteca = new Biblioteca();
        Livro livro = domCasmurro();
        biblioteca.emprestar(livro);
        assertEquals(0, biblioteca.devolver(livro, leitor("Ana", new Aluno()), 0));
        assertTrue(livro.estaDisponivel());
    }

    // As contas de multa agora são testadas em CalculadoraDeMultaTest, sem esperar e-mail.
    // Aqui fica um caso só, para provar que o balcão usa a calculadora.
    @Test
    void devolverComAtrasoCobraAMultaDaCalculadora() {
        Biblioteca biblioteca = new Biblioteca();
        Livro livro = domCasmurro();
        biblioteca.emprestar(livro);
        assertEquals(300, biblioteca.devolver(livro, leitor("Ana", new Aluno()), 3));
    }

    // Era o bug conhecido do início. Agora o próprio livro recusa o segundo empréstimo.
    @Test
    void naoEmprestaOMesmoLivroDuasVezes() {
        Biblioteca biblioteca = new Biblioteca();
        Livro livro = domCasmurro();
        biblioteca.emprestar(livro);
        assertThrows(IllegalStateException.class, () -> biblioteca.emprestar(livro));
    }

    @Test
    void naoDevolveLivroQueNaoFoiEmprestado() {
        Livro livro = domCasmurro();
        assertThrows(IllegalStateException.class, () -> new Biblioteca().devolver(livro, leitor("Ana", new Aluno()), 0));
    }
}
