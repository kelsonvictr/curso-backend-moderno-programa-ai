package br.com.biblioteca;

/**
 * Sabe uma coisa só: quanto custa o atraso.
 * Não pergunta "qual é o seu tipo?": pede ao tipo o valor do dia.
 */
public class CalculadoraDeMulta {

    public int calcular(Leitor leitor, int diasDeAtraso) {
        return diasDeAtraso * leitor.getTipo().multaPorDiaEmCentavos();
    }
}
