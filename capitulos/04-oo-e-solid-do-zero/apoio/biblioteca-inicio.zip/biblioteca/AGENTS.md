# Biblioteca do Bairro — instruções para o agente

Projeto de aula (Cap 04: OO e SOLID do zero). Java 21 puro, Maven Wrapper e JUnit 5.
Não há Spring, banco de dados, Docker nem rede de verdade.

## Como rodar
- Testes: `./mvnw test` (no Windows: `mvnw.cmd test`).
- Programa de exemplo: `./mvnw -q compile` e depois `java -cp target/classes br.com.biblioteca.App`.

## Regras
- O público está aprendendo orientação a objetos. Explique cada mudança em português simples,
  dizendo o problema, a mudança e como provar que funcionou.
- Antes de editar, mostre um plano curto e espere o OK.
- Uma tarefa por vez. Não adiantar passos futuros nem "melhorar" o que não foi pedido.
- Não adicionar dependências, frameworks, Lombok, records, lambdas ou streams no código de
  `src/main`. Nos testes, a única lambda permitida é a do `assertThrows(..., () -> ...)`.
- Não apagar testes. Se um teste documenta um bug conhecido, troque a expectativa pela regra
  nova e explique a diferença.
- Valores de dinheiro são inteiros em centavos (300 = R$ 3,00).
- Ao terminar: rode `./mvnw test`, mostre o resultado e o diff, e pare.

## Domínio
- Livro: código, título e se está disponível.
- Leitor: nome, e-mail e tipo (aluno ou professor).
- Multa por dia de atraso: aluno 100 centavos, professor 50 centavos.
- Se houver multa, o leitor recebe um aviso. `EmailSmtp` simula o envio e demora 2 segundos.
