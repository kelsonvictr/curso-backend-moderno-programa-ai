package br.com.biblioteca;

/**
 * Um dia no balcão: Ana pega Dom Casmurro e devolve com 3 dias de atraso.
 */
public class App {

    public static void main(String[] args) {
        Biblioteca biblioteca = new Biblioteca();

        Livro livro = new Livro("L-001", "Dom Casmurro");
        Leitor ana = new Leitor("Ana", "ana@email.com", "ALUNO");

        biblioteca.emprestar(livro);
        System.out.println("Ana pegou " + livro.getTitulo());

        int multa = biblioteca.devolver(livro, ana, 3);
        System.out.println("Ana devolveu com 3 dias de atraso. Multa: " + multa + " centavos");
    }
}
