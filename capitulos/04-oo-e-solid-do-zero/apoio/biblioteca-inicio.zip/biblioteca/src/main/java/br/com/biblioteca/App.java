package br.com.biblioteca;

/**
 * Um dia no balcão: Ana pega Dom Casmurro e devolve com 3 dias de atraso.
 */
public class App {

    public static void main(String[] args) {
        Livro livro = new Livro();
        livro.codigo = "L-001";
        livro.titulo = "Dom Casmurro";

        Leitor ana = new Leitor();
        ana.nome = "Ana";
        ana.email = "ana@email.com";
        ana.tipo = "ALUNO";

        Biblioteca biblioteca = new Biblioteca();
        biblioteca.emprestar(livro);
        System.out.println(livro.titulo + " disponível? " + livro.disponivel);

        int multa = biblioteca.devolver(livro, ana, 3);
        System.out.println("Multa: " + multa + " centavos");
        System.out.println(livro.titulo + " disponível? " + livro.disponivel);
    }
}
