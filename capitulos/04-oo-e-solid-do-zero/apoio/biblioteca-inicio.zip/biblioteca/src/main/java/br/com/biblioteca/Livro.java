package br.com.biblioteca;

/**
 * Um livro do acervo.
 * Hoje os campos são públicos: qualquer parte do programa pode mudar qualquer coisa.
 */
public class Livro {

    public String codigo;
    public String titulo;
    public boolean disponivel = true;
}
