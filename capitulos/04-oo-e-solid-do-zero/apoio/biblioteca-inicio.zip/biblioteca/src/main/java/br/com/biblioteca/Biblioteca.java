package br.com.biblioteca;

/**
 * O balcão da biblioteca. Funciona, mas faz tudo sozinho:
 * muda o livro, calcula a multa e manda o aviso.
 */
public class Biblioteca {

    public void emprestar(Livro livro) {
        livro.disponivel = false;
    }

    public int devolver(Livro livro, Leitor leitor, int diasDeAtraso) {
        livro.disponivel = true;

        int multa = 0;
        if (leitor.tipo.equals("ALUNO")) {
            multa = diasDeAtraso * 100;
        } else if (leitor.tipo.equals("PROFESSOR")) {
            multa = diasDeAtraso * 50;
        }

        if (multa > 0) {
            EmailSmtp email = new EmailSmtp();
            email.enviar(leitor.email, "Multa de " + multa + " centavos por " + diasDeAtraso + " dia(s) de atraso.");
        }
        return multa;
    }
}
