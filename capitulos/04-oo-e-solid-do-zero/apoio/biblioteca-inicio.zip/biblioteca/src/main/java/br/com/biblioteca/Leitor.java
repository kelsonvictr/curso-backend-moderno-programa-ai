package br.com.biblioteca;

/**
 * Quem pega livros emprestados.
 * O tipo é um texto: "ALUNO" ou "PROFESSOR".
 */
public class Leitor {

    public String nome;
    public String email;
    public String tipo;
}
