package br.com.biblioteca;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;

import org.junit.jupiter.api.Test;

class BibliotecaTest {

    private Livro domCasmurro() {
        Livro livro = new Livro();
        livro.codigo = "L-001";
        livro.titulo = "Dom Casmurro";
        return livro;
    }

    private Leitor leitor(String nome, String tipo) {
        Leitor leitor = new Leitor();
        leitor.nome = nome;
        leitor.email = nome.toLowerCase() + "@email.com";
        leitor.tipo = tipo;
        return leitor;
    }

    @Test
    void emprestarDeixaOLivroIndisponivel() {
        Livro livro = domCasmurro();
        new Biblioteca().emprestar(livro);
        assertFalse(livro.disponivel);
    }

    @Test
    void devolverNoPrazoNaoGeraMulta() {
        Biblioteca biblioteca = new Biblioteca();
        Livro livro = domCasmurro();
        biblioteca.emprestar(livro);
        assertEquals(0, biblioteca.devolver(livro, leitor("Ana", "ALUNO"), 0));
    }

    @Test
    void alunoPagaCemCentavosPorDiaDeAtraso() {
        Biblioteca biblioteca = new Biblioteca();
        Livro livro = domCasmurro();
        biblioteca.emprestar(livro);
        assertEquals(300, biblioteca.devolver(livro, leitor("Ana", "ALUNO"), 3));
    }

    @Test
    void professorPagaCinquentaCentavosPorDiaDeAtraso() {
        Biblioteca biblioteca = new Biblioteca();
        Livro livro = domCasmurro();
        biblioteca.emprestar(livro);
        assertEquals(150, biblioteca.devolver(livro, leitor("Bruno", "PROFESSOR"), 3));
    }

    // BUG CONHECIDO: o mesmo livro vai para duas pessoas e ninguém reclama.
    // Este teste só registra o comportamento de hoje. O passo 1 troca a expectativa.
    @Test
    void bugConhecido_emprestarDuasVezesNaoReclama() {
        Biblioteca biblioteca = new Biblioteca();
        Livro livro = domCasmurro();
        biblioteca.emprestar(livro);
        biblioteca.emprestar(livro);
        assertFalse(livro.disponivel);
    }
}
