package br.com.biblioteca;

/**
 * Contrato pequeno: o que todo item do acervo tem. Código e título, mais nada.
 * Quem empresta é o Livro; quem se baixa é o Baixavel. Cada um promete só o que faz.
 */
public interface ItemDoAcervo {

    String getCodigo();

    String getTitulo();
}
