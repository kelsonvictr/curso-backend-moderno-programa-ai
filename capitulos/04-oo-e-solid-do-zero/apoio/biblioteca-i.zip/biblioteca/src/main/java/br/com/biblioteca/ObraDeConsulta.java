package br.com.biblioteca;

/**
 * Dicionários e enciclopédias: estão no acervo, mas nunca saem da biblioteca.
 * Não é um Livro, então nem tem emprestar(). O compilador impede o engano.
 */
public class ObraDeConsulta implements ItemDoAcervo {

    private final String codigo;
    private final String titulo;

    public ObraDeConsulta(String codigo, String titulo) {
        this.codigo = codigo;
        this.titulo = titulo;
    }

    public String getCodigo() {
        return codigo;
    }

    public String getTitulo() {
        return titulo;
    }
}
