package br.com.biblioteca;

/** Contrato pequeno: o que se baixa em PDF. */
public interface Baixavel {

    String baixarPdf();
}
