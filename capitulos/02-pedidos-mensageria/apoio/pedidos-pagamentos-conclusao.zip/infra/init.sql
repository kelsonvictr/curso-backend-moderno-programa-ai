CREATE DATABASE pagamentos;
