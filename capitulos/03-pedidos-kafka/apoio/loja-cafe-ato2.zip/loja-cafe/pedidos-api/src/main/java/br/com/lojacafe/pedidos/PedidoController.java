package br.com.lojacafe.pedidos;

import jakarta.validation.Valid;
import java.util.List;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/pedidos")
public class PedidoController {

    private final PedidoRepository repository;
    private final PagamentosClient pagamentos;

    public PedidoController(PedidoRepository repository, PagamentosClient pagamentos) {
        this.repository = repository;
        this.pagamentos = pagamentos;
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public Pedido criar(@Valid @RequestBody NovoPedido novo) {
        Pedido pedido = new Pedido(novo.cliente(), novo.item(), novo.quantidade(), novo.precoUnitario());
        pedido = repository.save(pedido);

        // Ato 2: o cliente fica esperando enquanto o Pagamentos decide (~3 s).
        // Se o Pagamentos estiver fora, a exceção sobe e o cliente recebe 500,
        // mas o pedido já foi gravado e fica AGUARDANDO para sempre.
        PagamentosClient.Resposta resposta = pagamentos.pagar(pedido);
        pedido.concluir("APROVADO".equals(resposta.status()), resposta.motivo(), resposta.instancia());
        return repository.save(pedido);
    }

    @GetMapping
    public List<Pedido> listar() {
        return repository.findAllByOrderByIdDesc();
    }
}
