"""Pagamentos simulado da Loja Café · Ato 2: atende por HTTP (specs/pagamentos.md)."""
import os
import time

from flask import Flask, jsonify, request

INSTANCIA = os.getenv("INSTANCIA", "caixa-1")
PORTA = int(os.getenv("PORTA", "5001"))
LIMITE = 100.00  # acima disso, o "cartão de teste" recusa

app = Flask(__name__)


def decidir(valor):
    """Regra de negócio: devolve (status, motivo)."""
    time.sleep(3)  # finge que está falando com o banco
    if valor <= LIMITE:
        return "APROVADO", None
    return "RECUSADO", "limite do cartão de teste"


@app.post("/pagamentos")
def pagar():
    dados = request.get_json()
    status, motivo = decidir(float(dados["valor"]))
    print(f"[{INSTANCIA}] pedido {dados['pedidoId']} -> {status}", flush=True)
    return jsonify(pedidoId=dados["pedidoId"], status=status, motivo=motivo, instancia=INSTANCIA)


@app.get("/saude")
def saude():
    return jsonify(ok=True, instancia=INSTANCIA)


if __name__ == "__main__":
    app.run(port=PORTA)
