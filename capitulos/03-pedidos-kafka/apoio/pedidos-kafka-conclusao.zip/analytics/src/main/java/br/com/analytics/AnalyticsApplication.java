package br.com.analytics;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
@SpringBootApplication
public class AnalyticsApplication {
    public static void main(String[] args) { SpringApplication.run(AnalyticsApplication.class, args); }
}
