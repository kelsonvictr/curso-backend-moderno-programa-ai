package br.com.pedidos;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
@SpringBootTest
class PedidosApplicationIT {
    @Test void contextoCarrega() { }
}
