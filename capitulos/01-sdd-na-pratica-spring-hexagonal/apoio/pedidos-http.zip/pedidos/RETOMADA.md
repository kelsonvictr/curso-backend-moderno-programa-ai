# Retomada — HTTP, regras e persistência

Checkpoint `http` do Cap 1. Próximo passo: **Ato 5: implementar AdicionarItem por conta própria.**

1. Preserve seu projeto; extraia este ZIP em outra pasta e abra no IntelliJ com Java 21.
2. Compare com seu código. Anote o ponto recebido e uma diferença que entendeu.
3. Peça ao agente para ler este documento e as specs existentes antes de editar.
4. Rode `./mvnw test` (macOS/Linux) ou `mvnw.cmd test` (Windows). Se o ZIP perder permissão do script, use `sh mvnw test`.

O primeiro build baixa Maven/dependências; os binários não estão no ZIP. Versão fixa: Boot 3.5.16, Java 21.

## Banco local (checkpoints 4A em diante)
Peça ao agente para verificar conflito de porta e subir apenas o serviço do compose deste projeto.
- `docker compose -f infra/docker-compose.yml up -d`
- `docker compose -f infra/docker-compose.yml exec postgres pg_isready -U pedidos -d pedidos`
- `docker compose -f infra/docker-compose.yml exec postgres psql -U pedidos -d pedidos -c 'SELECT 1'`
Se precisar mudar a porta: defina PEDIDOS_DB_PORT no ambiente do compose e use a mesma porta em PEDIDOS_DB_URL (URL JDBC) para a aplicação/testes. Não apague volumes para resolver conflito.
Credenciais didáticas locais: pedidos / pedidos; não reutilizar em produção.

## Dois tipos de teste (4B em diante)
`./mvnw test` executa *Test, sem Spring ou banco. O teste de contexto original foi preservado como PedidosApplicationIT.
Com Postgres pronto, `./mvnw -Dtest='*IT' test` executa explicitamente contexto e integração. No Windows, use `mvnw.cmd "-Dtest=*IT" test`.
A evidência de persistência vem do teste de salvar e reler em transações separadas, não apenas de um BUILD SUCCESS dos unitários.

## Prova HTTP (4C)
Peça ao agente para iniciar a aplicação com `./mvnw spring-boot:run`, observar o log e executar:
```sh
curl -i -X POST localhost:8080/pedidos -H 'Content-Type: application/json' -d '{"clienteId":"c-1","itens":[{"sku":"CAFE-500","quantidade":2,"precoUnitario":18.90}]}'
```
Esperado: 201, UUID real, ABERTO, total numérico 37.80. 37.8 tem o mesmo valor.
Quantidade zero / lista vazia: 422 com mensagem e nenhuma gravação. JSON inválido/campos ausentes: 400.
Consulte o UUID no Postgres, encerre/reinicie apenas a aplicação e confira novamente a mesma linha e itens.
Não há GET ou AdicionarItem neste checkpoint. A prática individual começa daqui.

## Limites da referência
Exemplo didático local: sem autenticação, migrações, concorrência de atualizações ou infraestrutura de produção.
O total vem dos itens; UUID nasce no domínio. O rascunho vazio existe só durante a construção; CriarPedido recusa lista vazia antes de salvar.
