# Retomada — Domínio testado

Checkpoint `dominio` do Cap 1. Próximo passo: **Ato 3: caso de uso e ports.**

1. Preserve seu projeto; extraia este ZIP em outra pasta e abra no IntelliJ com Java 21.
2. Compare com seu código. Anote o ponto recebido e uma diferença que entendeu.
3. Peça ao agente para ler este documento e as specs existentes antes de editar.
4. Rode `./mvnw test` (macOS/Linux) ou `mvnw.cmd test` (Windows). Se o ZIP perder permissão do script, use `sh mvnw test`.

O primeiro build baixa Maven/dependências; os binários não estão no ZIP. Versão fixa: Boot 3.5.16, Java 21.

## Limites da referência
Exemplo didático local: sem autenticação, migrações, concorrência de atualizações ou infraestrutura de produção.
O total vem dos itens; UUID nasce no domínio. O rascunho vazio existe só durante a construção; CriarPedido recusa lista vazia antes de salvar.
