# Retomada — Adapter salva e recupera

Checkpoint `persistencia` do Cap 1. Próximo passo: **Checkpoint 4C: ligar REST ao caso de uso.**

1. Preserve seu projeto; extraia este ZIP em outra pasta e abra no IntelliJ com Java 21.
2. Compare com seu código. Anote o ponto recebido e uma diferença que entendeu.
3. Peça ao agente para ler este documento e as specs existentes antes de editar.
4. Rode `./mvnw test` (macOS/Linux) ou `mvnw.cmd test` (Windows). Se o ZIP perder permissão do script, use `sh mvnw test`.

O primeiro build baixa Maven/dependências; os binários não estão no ZIP. Versão fixa: Boot 3.5.16, Java 21.

## Banco local (checkpoints 4A em diante)
Peça ao agente para verificar conflito de porta e subir apenas o serviço do compose deste projeto.
- `docker compose -f infra/docker-compose.yml up -d`
- `docker compose -f infra/docker-compose.yml exec postgres pg_isready -U pedidos -d pedidos`
- `docker compose -f infra/docker-compose.yml exec postgres psql -U pedidos -d pedidos -c 'SELECT 1'`
Se precisar mudar a porta: defina PEDIDOS_DB_PORT no ambiente do compose e use a mesma porta em PEDIDOS_DB_URL (URL JDBC) para a aplicação/testes. Não apague volumes para resolver conflito.
Credenciais didáticas locais: pedidos / pedidos; não reutilizar em produção.

## Dois tipos de teste (4B em diante)
`./mvnw test` executa *Test, sem Spring ou banco. O teste de contexto original foi preservado como PedidosApplicationIT.
Com Postgres pronto, `./mvnw -Dtest='*IT' test` executa explicitamente contexto e integração. No Windows, use `mvnw.cmd "-Dtest=*IT" test`.
A evidência de persistência vem do teste de salvar e reler em transações separadas, não apenas de um BUILD SUCCESS dos unitários.

## Limites da referência
Exemplo didático local: sem autenticação, migrações, concorrência de atualizações ou infraestrutura de produção.
O total vem dos itens; UUID nasce no domínio. O rascunho vazio existe só durante a construção; CriarPedido recusa lista vazia antes de salvar.
